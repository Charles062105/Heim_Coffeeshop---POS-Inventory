<x-guest-layout>
    <!-- Session Status -->
    <x-auth-session-status class="mb-4" :status="session('status')" />

    <div class="mb-5 text-center">
        <p class="text-[10px] font-bold uppercase tracking-[0.3em] text-[#155d49]">Coffee Shop Operations</p>
        <h2 class="mt-2 text-xl font-bold text-gray-900">Sign in to HEIM</h2>
        <p class="text-xs text-gray-500 mt-1">Manage orders, payments, and inventory with ease.</p>
    </div>

    <form method="POST" action="{{ route('login') }}" class="space-y-4">
        @csrf

        <!-- Email Address -->
        <div>
            <x-input-label for="email" :value="__('Email Address')" class="text-xs font-bold text-gray-700 uppercase tracking-wider" />
            <x-text-input id="email" class="block mt-1 w-full border-gray-200 focus:border-[#155d49] focus:ring-[#155d49] rounded-xl text-sm" type="email" name="email" :value="old('email')" required autofocus autocomplete="username" placeholder="name@coffee.com" />
            <x-input-error :messages="$errors->get('email')" class="mt-2" />
        </div>

        <!-- Password -->
        <div>
            <x-input-label for="password" :value="__('Password')" class="text-xs font-bold text-gray-700 uppercase tracking-wider" />
            <div class="relative mt-1">
                <x-text-input id="password" class="block w-full pe-12 border-gray-200 focus:border-[#155d49] focus:ring-[#155d49] rounded-xl text-sm"
                                type="password"
                                name="password"
                                required autocomplete="current-password"
                                placeholder="••••••••" />
                <button type="button" id="toggle-password" class="absolute inset-y-0 end-0 flex items-center px-3 text-gray-400 hover:text-[#155d49] focus:outline-none focus:ring-2 focus:ring-inset focus:ring-[#155d49] rounded-e-xl" aria-label="Show password">
                    <svg id="password-eye" class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                    </svg>
                </button>
            </div>
            <x-input-error :messages="$errors->get('password')" class="mt-2" />
            @if ($errors->has('login'))
                <p class="mt-2 flex items-start gap-2 text-xs font-medium text-red-600" role="alert">
                    <span aria-hidden="true">⚠</span>
                    <span>{{ $errors->first('login') }}</span>
                </p>
            @endif
        </div>

        <!-- Remember Me -->
        <div class="flex items-center justify-between">
            <label for="remember_me" class="inline-flex items-center">
                <input id="remember_me" type="checkbox" class="rounded border-gray-300 text-[#155d49] shadow-sm focus:ring-[#155d49]" name="remember">
                <span class="ms-2 text-xs text-gray-600 font-medium">{{ __('Keep me signed in on this device') }}</span>
            </label>

            @if (Route::has('password.request'))
                <a class="text-xs font-semibold text-[#155d49] hover:underline" href="{{ route('password.request') }}">
                    {{ __('Forgot password?') }}
                </a>
            @endif
        </div>

        <div class="pt-2">
            <button type="submit" class="w-full py-3 bg-[#155d49] hover:bg-[#114a3b] active:bg-[#0d392e] text-white font-bold text-base rounded-xl shadow-lg shadow-emerald-900/20 transition flex items-center justify-center gap-2">
                <span>Log In</span>
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
            </button>
        </div>
    </form>

    <div class="mt-6 border-t border-gray-100 pt-4 text-center" aria-label="System status">
        <p class="flex items-center justify-center gap-1.5 text-xs font-semibold text-[#155d49]">
            <span class="h-2 w-2 rounded-full bg-[#155d49]" aria-hidden="true"></span>
            System Online
        </p>
        <p class="mt-1 text-[10px] font-medium uppercase tracking-wider text-gray-400">HEIM Coffee Shop POS &bull; v1.0</p>
    </div>

<script>
    document.getElementById('toggle-password')?.addEventListener('click', function () {
        const password = document.getElementById('password');
        const isHidden = password.type === 'password';

        password.type = isHidden ? 'text' : 'password';
        this.setAttribute('aria-label', isHidden ? 'Hide password' : 'Show password');
    });
</script>
</x-guest-layout>
