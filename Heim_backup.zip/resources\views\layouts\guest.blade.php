<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'Heim POS') }}</title>

        <link rel="icon" type="image/png" href="{{ asset('images/favicon.png') }}">
        <link rel="shortcut icon" href="{{ asset('favicon.ico') }}">

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=inter:400,500,600,700&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <body class="font-sans text-gray-900 antialiased bg-[#f0f8f5] relative overflow-x-hidden">
        {{-- Background Logo Watermark --}}
        <div class="pointer-events-none fixed inset-0 flex items-center justify-center overflow-hidden z-0 select-none" aria-hidden="true">
            <img src="{{ asset('images/logo.png') }}" alt="" class="w-[48rem] max-w-[90vw] opacity-[0.055] select-none filter blur-[0.2px] transform -rotate-6 scale-105 pointer-events-none">
        </div>

        <div class="relative z-10 min-h-screen flex flex-col sm:justify-center items-center pt-6 sm:pt-0 p-4">
            <div class="flex flex-col items-center gap-1 mb-2">
                <a href="/" class="flex flex-col items-center group">
                    <div class="h-16 w-44 rounded-2xl bg-white shadow-md border border-gray-100 flex items-center justify-center px-4 py-2 transition-transform group-hover:scale-105 duration-200">
                        <img src="{{ asset('images/logo.png') }}" alt="Heim Logo" class="h-full w-full object-contain" />
                    </div>
                    <p class="mt-2 text-[10px] font-semibold text-gray-500 uppercase tracking-[0.25em]">Coffee Shop Operations</p>
                </a>
            </div>

            <div class="w-full sm:max-w-md mt-3 px-8 py-7 bg-white/95 backdrop-blur-sm shadow-xl shadow-[#155d49]/5 rounded-2xl border border-gray-100">
                {{ $slot }}
            </div>
        </div>
    </body>
</html>
